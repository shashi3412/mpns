from flask import Flask, redirect, render_template, url_for,request
from flask_sqlalchemy import SQLAlchemy
import pymysql

import requests

app = Flask(__name__)
db = SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:password123@localhost/mpns_schema'
app.config['SECRET_KEY'] = 'asecretkey'

class emp_details(db.Model):
    __tablename__ = 'employee_details'
    emp_id = db.Column(db.Integer, primary_key=True,nullable=False)
    employee_name = db.Column(db.String(255),nullable=False)
    preferred_name = db.Column(db.String(255),nullable=False)
    designation = db.Column(db.String(255),nullable=False)
    group = db.Column(db.String(255),nullable=False)
    department = db.Column(db.String(255),nullable=False)
    email_id = db.Column(db.String(255),nullable=True)
    phone_no = db.Column(db.String(255),nullable=True)


@app.route('/',methods=['GET','POST'])
def home():
    if request.method == 'GET':
        emp_ids = []
        for i in emp_details.query.all():
            temp = []
            temp.append(i.emp_id)
            emp_ids.append(temp)
        return render_template('dashboard.html',emp_ids = emp_ids)
    if request.method == 'POST':
        print(request.form.getlist('emp_id[]'))
        emp_id = request.form.getlist('emp_id[]')[0]
        # emp_id = request.args['emp_id']
        return redirect(url_for('details',emp_id = emp_id))


@app.route('/details', methods=['GET','POST'])
def details(**kwargs):
    if request.method == 'GET':
        details = []
        if request.args['emp_id'] == "all":
            for i in emp_details.query.all():
                temp = []
                temp.append(i.emp_id)
                temp.append(i.employee_name)
                temp.append(i.preferred_name)
                temp.append(i.designation)
                temp.append(i.group)
                temp.append(i.department)
                temp.append(i.email_id)
                temp.append(i.phone_no)
                details.append(temp)
        else:
            # details = emp_details.query.filter(emp_details.emp_id == int(request.args['emp_id'])).all()
            for i in emp_details.query.filter(emp_details.emp_id == int(request.args['emp_id'])).all():
                temp = []
                temp.append(i.emp_id)
                temp.append(i.employee_name)
                temp.append(i.preferred_name)
                temp.append(i.designation)
                temp.append(i.group)
                temp.append(i.department)
                temp.append(i.email_id)
                temp.append(i.phone_no)
                details.append(temp)
            print(details)

        
        return render_template('details.html', details=details)


if __name__ == "__main__":
    app.run(debug=True)

